#### Bir stringin başka bir *string*'in döndürülmüş biçimi olup olmadığını sınayan

```
#include <string>

bool isRotate(const std::string &s1, const std::string &s2);

```

#### işlevini tanımlayınız.

#### İşlev eğer *s2* stringi *s1* stringinin döndürülmesiyle elde edilebiliyorsa *true* değere aksi halde *false* değere geri dönmeli.
