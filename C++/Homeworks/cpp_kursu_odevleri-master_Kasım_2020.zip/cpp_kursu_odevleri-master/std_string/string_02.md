#### *filename* isimli *std::string* nesnesi bir dosyanın ismini tutuyor. Aşağıdaki işlemleri gerçekleştirecek kodları yazınız.

+ Dosyanın uzantısı yok ise uzantısı *.jpg* olsun.  *(hasan) -> (hasan.jpg)*
+ Dosyanın uzantısı *".gif"* ise uzantısını *".png"* olarak değiştirin.  *(necati.gif) -> (necati.png)*
+ Dosyanın uzantısı *".xls"* ise uzantısını silin. *(aleyna.xls) -> (aleyna)*

