#### Aşağıdaki C++ programı hakkında yorum yapınız:

+ sentaks hatası
+ tanımsız davranış
+ derleyiciye göre değişir
+ ekrana şunu yazar: 

```
#include<iostream>

void func(int& ra, const int& rb) 
{
	std::cout << rb;
	ra = 1;
	std::cout << rb;
}

int main() 
{
	int ival = 0;

	func(ival, ival);
}

```

[ödev cevabı](https://vimeo.com/433209303)
