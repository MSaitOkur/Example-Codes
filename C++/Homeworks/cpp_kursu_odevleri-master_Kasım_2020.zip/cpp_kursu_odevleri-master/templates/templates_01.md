#### Bir tam sayının bir tam sayı kuvvetini hesaplayacak _Power_ isimli meta fonksiyonu yazınız. 

`constexpr int x = Power<2, 5>::value; //x = 32`

#### power_v isimli bir değişken şablonu _(variable template)_ oluşturunuz.

`constexpr int y = power_v<3, 5>;`
