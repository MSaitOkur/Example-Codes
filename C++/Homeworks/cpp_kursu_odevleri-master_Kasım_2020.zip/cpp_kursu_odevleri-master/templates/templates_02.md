#### Bir tam sayının faktöriyel değerini hesaplayacak _Factorial_ isimli meta fonksiyonu yazınız. 
Sınıfın `constexpr value` isimli öğesi hesaplanacak faktöriyel değeri olacak:

`constexpr int x = Factorial<5>::value; //x = 120`

#### factorial_v isimli bir değişken şablonu _(variable template)_ oluşturunuz.

`constexpr int y = factorial_v<7>;`
