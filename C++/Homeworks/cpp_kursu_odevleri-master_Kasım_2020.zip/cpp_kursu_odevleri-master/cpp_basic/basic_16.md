#### Aşağıdaki C++ programı hakkında yorum yapınız:

+ sentaks hatası
+ tanımsız davranış
+ derleyiciye göre değişir
+ ekrana şunu yazar: 

```
#include <iostream>

int main()
{
	int x = 10;
	int y = 20;
	int z;
	z = x, y;
	std::cout << z;
}
```
